Hallo!
Du hast mein Tutorial auf YouTube angeschaut, wie du deine Aufgenommenen Daten deines Samsung-TVs in ein
verwendbares Format Konvertieren kannst.
Alle Daten sind 100% Virenfrei!
Das Programm ist freeware und legal zu haben :-)
#########################################################################################################

Um die Daten von deiner Record-Festplatte auf dein Windwos zu bekommen, ben�tigst du den VMware Player
und ein Linux. Am einfachsten geht es mit Ubuntu!

#########################################################################################################

Bei fragen, stell diese einfach als Videokomentar unter das Tutorial!

#########################################################################################################

Folgende Links k�nnten dich interessieren:

DU hast folgendes Tutorial angeschaut: http://youtu.be/aB1FZMGi4KA
~~~~~~~~~~~~~~~~~~~~~~~~
youtube.com/hoerlilp
hoerli2.de.to
facebook.com/djhoerli
twitter.com/djhoerli
~~~~~~~~~~~~~~~~~~~~~~~~


Bei weitergabe DIESER Daten, gebe IMMER dieses Tutorial mit an!


#########################################################################################################

Videobeschreibung des Tutorials:

[TUT] Samsung TV-Aufnahmen in ein verwendbares Format konvertieren
############################################################

In diesem Tutorial zeige ich euch, wie ihr die Aufnahmen von eurem Samsung TV auf den PC kopieren k�nnt 
und danach in ein verwendbares Format konvertieren k�nnt.

Dazu ist nur dieses Programm notwenig: LINK FOLGT

~~~ HINWEIS ~~~
Das Programm stammt NICHT von mir. Ich bin nicht der entwickler davon und kenne diesen selbst auch NICHT. 
Es ist Virenfrei!
Bei Problemen mit dem Programm, versucht den Entwickler zu kontaktieren!

Ebenfalls ist ein Linux notwendig! Daf�r hab ich f�r euch folgende Links mal rausgesucht:
VMware Player: http://www.chip.de/downloads/VMware-Player_12994646.html
Ubuntu 64-bit: http://www.chip.de/downloads/Ubuntu-64-Bit_42589318.html
Ubuntu 32-bit: http://www.chip.de/downloads/Ubuntu-32-Bit_22592231.html

############################################################

Dieses Tutorial ist eine Erweiterung zu diesem: http://www.youtube.com/watch?v=4w95YVxdPlE
schaut es euch mal an, falls ihr die PVR-Funktion noch nicht aktiviert habt.

############################################################

Viel Erfolg beim Konvertieren :-)